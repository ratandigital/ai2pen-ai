<?php

namespace Illuminate\Contracts\Database\Query;

/**
 * This interface is intentionally empty and exists to improve IDE support.
 *
 * @mixin \Illuminate\Database\Query\Builder
 */
interface Builder
{
}
