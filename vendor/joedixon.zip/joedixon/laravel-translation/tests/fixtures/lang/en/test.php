<?php

return array (
  'hello' => 'Hello',
  'whats_up' => 'What\'s up!',
);
